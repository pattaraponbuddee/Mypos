from django.apps import AppConfig


class MyposappConfig(AppConfig):
    name = 'Myposapp'
